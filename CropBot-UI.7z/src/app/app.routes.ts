import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule, UrlSegment } from '@angular/router';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
    {path:'', component: HomeComponent},
    {path:'**',redirectTo:'login',pathMatch:'full'}
];

export const AppRouter: ModuleWithProviders = RouterModule.forRoot(routes);