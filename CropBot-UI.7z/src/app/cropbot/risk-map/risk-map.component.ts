import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-risk-map',
  templateUrl: './risk-map.component.html',
  styleUrls: ['./risk-map.component.scss']
})
export class RiskMapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
