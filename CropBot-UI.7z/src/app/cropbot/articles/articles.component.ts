import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import {map} from 'rxjs/operators'
@Component({
  selector: 'app-articles',
  templateUrl: './articles.component.html',
  styleUrls: ['./articles.component.scss']
})
export class ArticlesComponent implements OnInit {
  articles:any[];
  postKey:string[];
  categoryList:string[]
  url:string='https://newsapi.org/v2/top-headlines?country=us&apiKey=2267c044327043539a079634c1c36d89';
  constructor(public http:HttpClient) {
   this.postKey=[];
   this.articles=[];
   this.categoryList=['Geo Political','Violence','Crime'];
   }

   getPosts(url:string) :Observable<any>{
     let payload={"articleId":"123456"};
    return  this.http.get(url);
   }

  ngOnInit() {
    if(!localStorage.getItem(this.url))
    this.getPosts(this.url).subscribe(
      data=>{console.log(data);
        this.articles=data.articles;
        localStorage.setItem(this.url,JSON.stringify(this.articles));
        this.postKey=Object.keys(this.articles[0]);
        console.log(this.postKey);
      },
      error=>{console.log(error);},
      ()=>{
          console.log("request finished");
      }
    )
    else{
      this.articles = JSON.parse(localStorage.getItem(this.url));
    }
  }

}
