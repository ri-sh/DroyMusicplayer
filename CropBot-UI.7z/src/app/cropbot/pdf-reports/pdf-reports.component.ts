import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pdf-reports',
  templateUrl: './pdf-reports.component.html',
  styleUrls: ['./pdf-reports.component.scss']
})
export class PdfReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
