import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { Routes, RouterModule, UrlSegment } from '@angular/router';
import { CommonModule } from '@angular/common';
import {HttpClientModule} from '@angular/common/http'

import { NgStickyDirective } from 'ng-sticky';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {MatSliderModule} from '@angular/material/slider';
import {MatMenuModule} from '@angular/material/menu';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatCardModule} from '@angular/material/card';

import { HomeComponent } from './home/home.component';
import { ArticlesComponent } from './articles/articles.component';
import { EventTrackerComponent } from './event-tracker/event-tracker.component';
import { RiskMapComponent } from './risk-map/risk-map.component';
import { NavbarComponent } from './navbar/navbar.component';
import { cropbotRoutes } from './cropbot.routes';
import { PdfReportsComponent } from './pdf-reports/pdf-reports.component';
import { ArticleDetailsComponent } from './article-details/article-details.component';
@NgModule({
  imports: [
    BrowserAnimationsModule,
    CommonModule,
    HttpClientModule,
    FlexLayoutModule,
    MatIconModule,
    MatButtonModule,
    MatSliderModule,
    MatSidenavModule,
    MatMenuModule,
    MatCardModule,
    RouterModule.forChild(cropbotRoutes),
   
  ],
  declarations: [ NgStickyDirective ,HomeComponent, ArticlesComponent, EventTrackerComponent, RiskMapComponent,NavbarComponent, PdfReportsComponent, ArticleDetailsComponent,]
})
export class CropbotModule { }
