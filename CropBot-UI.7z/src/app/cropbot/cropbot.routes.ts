import { Routes, RouterModule, UrlSegment } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { HomeComponent } from './home/home.component';
import { ArticlesComponent } from './articles/articles.component';
import { EventTrackerComponent } from './event-tracker/event-tracker.component';
import { RiskMapComponent } from './risk-map/risk-map.component';
import { PdfReportsComponent } from './pdf-reports/pdf-reports.component'
import {ArticleDetailsComponent} from './article-details/article-details.component'
export const cropbotRoutes:Routes = [
    {
        path:'', component:HomeComponent,
        children: [
            {path:'',redirectTo:'articles',pathMatch:'full'},
            {
                path:'articles', component:ArticlesComponent,
            },
            {
                path:'articles/:id', component:ArticleDetailsComponent,
            },
            {path:'events', component:EventTrackerComponent},
            {path:'risk-map', component:RiskMapComponent},
            {path:'reports',component:PdfReportsComponent}
        ]
    }
];
