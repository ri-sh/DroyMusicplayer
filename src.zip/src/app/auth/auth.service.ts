import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject,Observable } from 'rxjs';
import { User } from './user';
import { user_details } from './user_details';
import {HttpClient} from '@angular/common/http';
import 'rxjs/add/operator/delay'
@Injectable()
export class AuthService {
  public user_details: user_details;
  public user_details_1: user_details;
  public loggedIn = new BehaviorSubject<boolean>(false); // {1} To control if the user is logged in or not, we will use a BehaviorSubject
  public _url:string = "assets/userlist.json";

  
  get isLoggedIn() {
    return this.loggedIn.asObservable(); // {2}create a getter to expose only the get method publicly
  }

  constructor(
    public router: Router,
    public http: HttpClient
  ) {}

  login(user: User)
  {//modify this method in the future to validate with the backend API
    return this.get_user().delay(10); 
  }

  get_user():Observable<user_details>
  {
    return this.http.get<user_details>(this._url);
  }

  logout() {                            // {4}
    this.loggedIn.next(false);
    this.router.navigate(['/login']);
  }
}