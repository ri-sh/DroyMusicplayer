export class user_details {
    userName:String;
    access:Boolean;
  }