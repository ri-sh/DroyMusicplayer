import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { AppRouter } from './app.routes';

import {MatBadgeModule} from '@angular/material/badge';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MatMenuModule} from '@angular/material/menu';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatProgressBarModule} from '@angular/material/progress-bar'
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatCardModule} from '@angular/material/card';
import {MatInputModule} from '@angular/material';
import {MatTooltipModule} from '@angular/material/tooltip';
import { FormsModule } from '@angular/forms';




import {HttpWrapperService} from './core-services/http-wrapper.service';

import {CropbotModule} from './cropbot/cropbot.module';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { NotFoundComponent } from './shared/not-found/not-found.component';

import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import { AuthService } from './auth/auth.service';
import {HttpClientModule} from '@angular/common/http';
import {MatRadioModule} from '@angular/material/radio';




@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
     NotFoundComponent,
  ],
  imports: [
    BrowserModule,
    CropbotModule,
    FlexLayoutModule,
    AppRouter,

    
    MatCardModule,
    MatIconModule,
    MatButtonModule,
    MatBadgeModule,
    MatMenuModule,
    MatTooltipModule,
    
    MatSnackBarModule,
    MatProgressBarModule,
    MatInputModule,
    FlexLayoutModule,
    MatFormFieldModule,
    AppRouter,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    HttpClientModule ,
    MatRadioModule,
    FormsModule,
  ],
  providers: [AuthService,HttpWrapperService],
  bootstrap: [AppComponent]
})
export class AppModule {}