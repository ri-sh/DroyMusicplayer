import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from './../auth/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})

export class LoginComponent implements OnInit {
  form: FormGroup;                    // {1}form variable 
  private formSubmitAttempt: boolean; // {2}
  public isloged:string="";
  public showprogressbar:boolean=false;
  
  constructor(
    private fb: FormBuilder,         // {3}inject it in component’s contructor
    private authService: AuthService,
    public router: Router
     // {4}We also need to inject it in the component’s contructor.
   //This service was declared as provider in the app.module
  ) {

  }

  ngOnInit() {
       
    this.form = this.fb.group({     // {5}two fields: user name and password and they are both required
      userName: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  isFieldInvalid(field: string) { // {6}To display some validation error messages in our form, 
  //we’ll verify if the field is invalid or has been touched
    return (
      (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt)
    );
  }

  onSubmit() {
    this.showprogressbar=true;
    if (this.form.valid) {
      this.authService.login(this.form.value).subscribe(data=>
        { // {3}If we received a userName and a password 
        this.authService.user_details_1=data;
        if( this.authService.user_details_1.access==true)
          {
            this.authService.loggedIn.next(true);
            this.router.navigate(['/']);
          }
          else
          this.isloged="Username and/or the password is incorrect";
          this.showprogressbar=false;
      }
      )      
      // {7} in the constructor,
   // when the user clicks on the login button and the form is valid, we will submit its values
    }
    else 
    this.showprogressbar=false;
    this.formSubmitAttempt = true;  // {8} using the submit attempt flag approach
    
  }
}