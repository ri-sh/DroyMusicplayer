import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule, UrlSegment } from '@angular/router';
import { LandingComponent} from './cropbot/landing/landing.component'
import { LoginComponent } from './login/login.component';
import {AuthGuard} from './auth/auth.guard'
const routes: Routes = [
  { path: '', component:LandingComponent },
  { path: 'login', component: LoginComponent },
  { path: '**', redirectTo: 'login'}
];

export const AppRouter: ModuleWithProviders = RouterModule.forRoot(
    routes, { useHash: true }
    //{enableTracing:true}
);
