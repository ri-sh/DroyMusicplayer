import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Response, Headers, RequestOptions } from '@angular/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { environment } from '../../environments/environment';
import { MatSnackBar } from '@angular/material';

/*
 *  Author: Rishabh Roy
 *  Description: Wrapper service over Http-Client of angular,
 *  to handle responses from the server to do
 *  error handling and showing snack-bars accordingly.
 *  Sets headers with content-type 'text/plain' to avoid
 *  CORS issues.
*/

@Injectable()
export class HttpWrapperService {
  constructor(
    private http: HttpClient,
    public snackBar: MatSnackBar,
    private router: Router
  ) {}
}