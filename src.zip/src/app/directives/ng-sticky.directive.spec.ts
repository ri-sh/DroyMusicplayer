import { NgStickyDirective } from './ng-sticky.directive';

describe('NgStickyDirective', () => {
  it('should create an instance', () => {
    const directive = new NgStickyDirective();
    expect(directive).toBeTruthy();
  });
});
