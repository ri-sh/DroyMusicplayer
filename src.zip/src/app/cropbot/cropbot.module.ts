import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import {FormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { Routes, RouterModule, UrlSegment } from '@angular/router';
import { CommonModule } from '@angular/common';
import {HttpClientModule} from '@angular/common/http'
import {AuthGuard} from '../auth/auth.guard'
import {MatRadioModule} from '@angular/material/radio';

import { NgStickyDirective } from '../directives/ng-sticky.directive';

import {FlexLayoutModule} from '@angular/flex-layout';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {MatSliderModule} from '@angular/material/slider';
import {MatMenuModule} from '@angular/material/menu';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatTooltipModule} from '@angular/material/tooltip';



import { LandingComponent } from './landing/landing.component';
import { HeaderComponent } from '../shared/header/header.component';
import { FooterComponent } from '../shared/footer/footer.component';
import { ArticlesComponent } from './articles/articles.component';
import { EventTrackerComponent } from './event-tracker/event-tracker.component';
import { RiskMapComponent } from './risk-map/risk-map.component';
import { NavbarComponent } from './navbar/navbar.component';
import { cropbotRoutes } from './cropbot.routes';
import { PdfReportsComponent } from './pdf-reports/pdf-reports.component';
import { ArticleDetailsComponent } from './article-details/article-details.component';
import {MatInputModule} from '@angular/material';
import {MatNativeDateModule} from '@angular/material';
import {MatCheckboxModule} from '@angular/material/checkbox';



@NgModule({
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    CommonModule,
    HttpClientModule,
    FlexLayoutModule,
    MatIconModule,
    MatButtonModule,
    MatSliderModule,
    MatSidenavModule,
    MatMenuModule,
    MatCardModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatRadioModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule, 
    ReactiveFormsModule,
    MatTooltipModule,
    MatCheckboxModule,
    RouterModule.forChild(cropbotRoutes),
   ],
  providers:[
    AuthGuard
  ],
  declarations: [ 
    NgStickyDirective,
    LandingComponent, 
    ArticlesComponent,
    EventTrackerComponent,
    RiskMapComponent,
    NavbarComponent,
    PdfReportsComponent, 
    ArticleDetailsComponent,
    HeaderComponent, 
    FooterComponent,
    
  ]
})
export class CropbotModule { }
