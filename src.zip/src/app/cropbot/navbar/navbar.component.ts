import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {

  navLinks:any[];
  constructor() {
    this.navLinks=[
      {"link":'/story-maps','link-text':'Story Maps'},
      {"link":'/articles','link-text':'Articles'},
      {"link":'/events','link-text':'Events'},
      {"link":'/risk-map','link-text':'Risk Map'},
      {"link":'/reports','link-text':'Reports'}
    ];
   }

  ngOnInit() {
  }

}
