import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import {map} from 'rxjs/operators'
import {MatInputModule} from '@angular/material';
import { FormGroup, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';


@Component({
  selector: 'app-articles',
  templateUrl: './articles.component.html',
  styleUrls: ['./articles.component.scss']
})
export class ArticlesComponent implements OnInit {
  
  constructor(public http:HttpClient,private fb: FormBuilder) {
    
    this.End_date=new FormControl(new Date());
    this.Begin_date=new FormControl(new Date());
    this.Geo_all_chckd= true;
    this.Cat_all_chckd= true;
   this.postKey=[];
   this.articles=[];
   this.categoryList=['Geopolitical','Violence','Crime','Terrorism','Health','Cyber','Travel','Society','Environment','Fraud','Digital-Physical']

   this.countrys= ['Zimbabwe','Zambia','Yemen','Virgin Islands (US)','Virgin Islands (UK)','Vietnam','Venezuela','Nigeria','Niger','Nicaragua','New Zealand','Netherlands','Nepal','Namibia','Mozambique','Morocco','Montserrat','Montenegro','Mongolia','Monaco','Moldova',,'Mayotte','Mauritius','Mauritania','Martinique','Malta','Mali','Maldives','Malaysia','Malawi','Madagascar','Luxembourg','Lithuania','Liechtenstein','Libya','Liberia','Lesotho','Lebanon','Latvia','Laos','Kyrgyz Republic','Kuwait','Kosovo','Kenya','Kazakhstan','Jordan','Japan','Jamaica','Ivory Coast','Italy','Israel and the Occupied Territories','Iraq','Iran','Indonesia','India','Iceland','Hungary','Honduras','Haiti','Guyana','Guinea-Bissau','Guinea','Guatemala','Guadeloupe','Grenada','Greece','Great Britain','Ghana','Germany','Georgia','Gambia','Gabon','French Guiana','France','Finland','Fiji','Ethiopia','Estonia','Eritrea','Equatorial Guinea','El Salvador','Egypt','Ecuador','Dominican Republic','Dominica','Djibouti','Denmark','Democratic Republic of the Congo','Czech Republic','Cyprus','Cuba','Croatia','Costa Rica','Congo','Comoros','Colombia','China','Chile','Chad','Central African Republic','Cayman Islands','Cape Verde','Canada','Cameroon','Cambodia','Burundi','Myanmar/Burma','Burkina Faso','Bulgaria','Brunei Darussalam','Brazil','Botswana','Bosnia & Herzegovina','Bolivia','Bhutan','Bermuda','Benin','Belize','Belgium','Belarus','Barbados','Bangladesh','Bahrain','Bahamas','Azerbaijan','Austria','Australia','Armenia','Argentina','Antigua & Barbuda','Anguilla','Angola','Andorra','Algeria','Albania','Afghanistan'];
  }
  Geo_all_chckd:boolean;
  Cat_all_chckd:boolean;
  filter_form: FormGroup;   
  articles:any[];
  postKey:string[];
  categoryList:string[]
  url:string='https://newsapi.org/v2/top-headlines?country=us&apiKey=2267c044327043539a079634c1c36d89';
  countrys:String[];
  minDate = new Date(2000, 0, 1);
  maxDate = new Date(2020, 0, 1);
  End_date = new FormControl(new Date());
  Begin_date = new FormControl(new Date());
  Dates:string[];
  
   getPosts(url:string) :Observable<any>{
    let payload={"articleId":"123456"};
    return  this.http.get(url);
   }

  ngOnInit() {
    this.filter_form = this.fb.group({     // country,category and the timefram are the felds required here
      country: [''],
      category: [''],
      begin_time:[''],
      end_time:['']
    });
    if(!localStorage.getItem(this.url))
    this.getPosts(this.url).subscribe(
      data=>{
        console.log(data);
        this.articles=data.articles;
        localStorage.setItem(this.url,JSON.stringify(this.articles));
        this.postKey=Object.keys(this.articles[0]);
        console.log(this.postKey);
      },
      error=>{console.log(error);},
      ()=>{
          console.log("request finished");
      }
    )
    else{
      this.articles = JSON.parse(localStorage.getItem(this.url)).slice(0,4);
      console.log(this.articles);
    }
  }

  onSubmit()
  {
//form submit will subscribe the service for changing articles in the list
  }

}
