import { CropbotModule } from './cropbot.module';

describe('CropbotModule', () => {
  let cropbotModule: CropbotModule;

  beforeEach(() => {
    cropbotModule = new CropbotModule();
  });

  it('should create an instance', () => {
    expect(cropbotModule).toBeTruthy();
  });
});
