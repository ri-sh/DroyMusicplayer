import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-tracker',
  templateUrl: './event-tracker.component.html',
  styleUrls: ['./event-tracker.component.scss']
})
export class EventTrackerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
